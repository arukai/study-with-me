class Timer {
    constructor() {
        this.timeLeft = 25 * 60; // 25 минут в секундах
        this.isRunning = false;
        this.interval = null;
        this.currentMode = 'pomodoro';
        this.initializeElements();
        this.initializeControls();
    }

    initializeElements() {
        this.display = document.querySelector('.timer-display');
        this.startBtn = document.getElementById('startTimer');
        this.pauseBtn = document.getElementById('pauseTimer');
        this.resetBtn = document.getElementById('resetTimer');
        this.modeButtons = document.querySelectorAll('.mode-btn');
    }

    initializeControls() {
        // Управление таймером
        this.startBtn?.addEventListener('click', () => this.start());
        this.pauseBtn?.addEventListener('click', () => this.pause());
        this.resetBtn?.addEventListener('click', () => this.reset());

        // Переключение режимов
        this.modeButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const minutes = parseInt(e.target.dataset.time);
                this.setTime(minutes);
                this.updateModeButtons(e.target);
            });
        });
    }

    setTime(minutes) {
        this.pause();
        this.timeLeft = minutes * 60;
        this.updateDisplay();
    }

    updateModeButtons(activeButton) {
        this.modeButtons.forEach(btn => btn.classList.remove('active'));
        activeButton.classList.add('active');
    }

    start() {
        if (!this.isRunning) {
            this.isRunning = true;
            this.interval = setInterval(() => this.tick(), 1000);
            this.startBtn.disabled = true;
            this.pauseBtn.disabled = false;
        }
    }

    pause() {
        this.isRunning = false;
        clearInterval(this.interval);
        this.startBtn.disabled = false;
        this.pauseBtn.disabled = true;
    }

    reset() {
        this.pause();
        const activeMode = document.querySelector('.mode-btn.active');
        const minutes = parseInt(activeMode.dataset.time);
        this.timeLeft = minutes * 60;
        this.updateDisplay();
    }

    tick() {
        if (this.timeLeft > 0) {
            this.timeLeft--;
            this.updateDisplay();
        } else {
            this.onComplete();
        }
    }

    updateDisplay() {
        const minutes = Math.floor(this.timeLeft / 60);
        const seconds = this.timeLeft % 60;
        this.display.textContent = 
            `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }





    setCustomTime(seconds) {
        this.pause();
        this.timeLeft = seconds;
        this.updateDisplay();
    }
}

class Progress {
    static init() {
        this.minutes = parseInt(localStorage.getItem('studyMinutes')) || 0;
        this.sessions = parseInt(localStorage.getItem('sessions')) || 0;
        this.updateUI();
    }

    static addSession(actualMinutes) {
        if (actualMinutes <= 0) return; // Игнорируем нулевое или отрицательное время
        this.sessions++;
        this.minutes += actualMinutes; // Добавляем фактическое время
        this.saveToStorage();
        this.updateUI();
    }

    static saveToStorage() {
        localStorage.setItem('studyMinutes', this.minutes);
        localStorage.setItem('sessions', this.sessions);
    }

    static updateUI() {
        const minutesElement = document.getElementById('totalMinutes');
        const sessionsElement = document.getElementById('totalSessions');
        if (minutesElement) minutesElement.textContent = this.minutes;
        if (sessionsElement) sessionsElement.textContent = this.sessions;
    }
}

class WaterTracker {
    constructor() {
        this.total = parseInt(localStorage.getItem('waterAmount')) || 0;
        this.initializeControls();
    }

    initializeControls() {
        const waterButtons = document.querySelectorAll('.water-add');
        waterButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const amount = parseInt(e.target.dataset.ml);
                this.addWater(amount);
            });
        });
        this.updateUI();
    }

    addWater(amount) {
        this.total += amount;
        localStorage.setItem('waterAmount', this.total);
        this.updateUI();
        this.showNotification(amount);
    }

    updateUI() {
        const waterTotal = document.getElementById('waterTotal');
        if (waterTotal) {
            waterTotal.textContent = `${this.total} мл`;
            // Добавляем анимацию при обновлении
            waterTotal.classList.add('update-animation');
            setTimeout(() => waterTotal.classList.remove('update-animation'), 500);
        }
    }

    showNotification(amount) {
        const notification = document.createElement('div');
        notification.className = 'water-notification';
        notification.textContent = `+${amount} мл воды добавлено!`;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 2000);
    }
}

// Класс для управления темой
class ThemeManager {
    constructor() {
        this.theme = localStorage.getItem('theme') || 'dark'; // По умолчанию темная тема
        this.themeToggle = document.getElementById('themeToggle');
        this.init();
    }

    init() {
        // Установка начальной темы
        this.setTheme(this.theme);
        
        // Добавление обработчика событий для кнопки
        if (this.themeToggle) {
            this.themeToggle.addEventListener('click', () => this.toggleTheme());
        }

        // Следим за системными настройками
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
            this.setTheme(e.matches ? 'dark' : 'light');
        });
    }

    setTheme(theme) {
        this.theme = theme;
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);
        
        // Обновляем иконку
        if (this.themeToggle) {
            this.themeToggle.innerHTML = theme === 'dark' ? '☀️' : '🌙';
            this.themeToggle.setAttribute('title', 
                theme === 'dark' ? 'Переключить на светлую тему' : 'Переключить на темную тему'
            );
        }
    }

    toggleTheme() {
        const newTheme = this.theme === 'dark' ? 'light' : 'dark';
        this.setTheme(newTheme);
        
        // Добавляем анимацию при переключении
        document.documentElement.classList.add('theme-transition');
        setTimeout(() => {
            document.documentElement.classList.remove('theme-transition');
        }, 300);
    }
}








//тудулист
const inputField = document.querySelector(".input-field textarea"),
  todoLists = document.querySelector(".todoLists"),
  pendingNum = document.querySelector(".pending-num"),
  clearButton = document.querySelector(".clear-button");


function allTasks() {
  let tasks = document.querySelectorAll(".pending");

  pendingNum.textContent = tasks.length === 0 ? "0" : tasks.length;

  let allLists = document.querySelectorAll(".list");
  if (allLists.length > 0) {
    todoLists.style.marginTop = "20px";
    clearButton.style.pointerEvents = "auto";
    return;
  }
  todoLists.style.marginTop = "0px";
  clearButton.style.pointerEvents = "none";
}


inputField.addEventListener("keyup", (e) => {
  let inputVal = inputField.value.trim();

  if (e.key === "Enter" && inputVal.length > 0) {
    let liTag = ` <li class="list pending" onclick="handleStatus(this)">
          <input type="checkbox" />
          <span class="task">${inputVal}</span>
          <i class="uil uil-trash" onclick="deleteTask(this)"></i>
        </li>`;

    todoLists.insertAdjacentHTML("beforeend", liTag); 
    inputField.value = ""; 
  }
});


function handleStatus(e) {
  const checkbox = e.querySelector("input"); 
  checkbox.checked = checkbox.checked ? false : true;
  e.classList.toggle("pending");
  allTasks();
}


function deleteTask(e) {
  e.parentElement.remove(); 
  allTasks();
}


clearButton.addEventListener("click", () => {
  todoLists.innerHTML = "";
  allTasks();
});





//калькулятор//
const display = document.querySelector(".display");
const buttons = document.querySelectorAll("button");
const specialChars = ["%", "*", "/", "-", "+", "="];
let output = "";

const calculate = (btnValue) => {
  display.focus();

  if (btnValue === "=" && output !== "") {
    try {
      // Заменим % на деление на 100 и посчитаем
      output = eval(output.replace(/%/g, "/100"));
    } catch (err) {
      output = "Ошибка";
    }
  } else if (btnValue === "AC") {
    output = "";
  } else if (btnValue === "DEL") {
    output = output.toString().slice(0, -1);
  } else {
    // Блокируем ввод операторов первым символом
    if (output === "" && specialChars.includes(btnValue)) return;

    // Блокируем два оператора подряд
    const lastChar = output[output.length - 1];
    if (specialChars.includes(lastChar) && specialChars.includes(btnValue)) {
      return;
    }

    output += btnValue;
  }

  display.value = output;
};

// Навешиваем обработчики
buttons.forEach((button) => {
  button.addEventListener("click", (e) => {
    const value = e.target.dataset.value;
    if (value !== undefined) {
      calculate(value);
    }
  });
});




const listButton = document.getElementById("listButton");
const calculatorButton = document.getElementById("calculatorButton");
const waterTrackerButton = document.getElementById("waterTrackerButton");

const todoSection = document.querySelector(".todo-app");
const calculatorSection = document.querySelector(".calculator-app");
const waterSection = document.querySelector(".water-section");

function hideAllSections() {
  todoSection.style.display = "none";
  calculatorSection.style.display = "none";
  waterSection.style.display = "none";
}

listButton.addEventListener("click", () => {
  hideAllSections();
  todoSection.style.display = "block";
});

calculatorButton.addEventListener("click", () => {
  hideAllSections();
  calculatorSection.style.display = "block";
});

waterTrackerButton.addEventListener("click", () => {
  hideAllSections();
  waterSection.style.display = "block";
});

// По умолчанию показываем список задач
hideAllSections();
todoSection.style.display = "block";



const sections = [document.querySelector(".todo-app"), document.querySelector(".calculator-app"), document.querySelector(".water-section")];
let currentIndex = 0;

function showSection(index) {
  sections.forEach((sec, i) => {
    sec.style.display = i === index ? "block" : "none";
  });
}

showSection(currentIndex); // Показываем первую секцию при загрузке

// Обработка свайпа
let startX = 0;

document.addEventListener("touchstart", (e) => {
  startX = e.touches[0].clientX;
});

document.addEventListener("touchend", (e) => {
  const endX = e.changedTouches[0].clientX;
  const diff = startX - endX;

  if (Math.abs(diff) > 50) { // Если движение достаточно большое
    if (diff > 0) {
      // свайп влево
      currentIndex = (currentIndex + 1) % sections.length;
    } else {
      // свайп вправо
      currentIndex = (currentIndex - 1 + sections.length) % sections.length;
    }
    showSection(currentIndex);
  }
});









//таймер
class CustomTimer {
    constructor(timer) {
        this.mainTimer = timer;
        this.modal = document.getElementById('customTimerModal');
        this.minutesInput = document.getElementById('customMinutes');
        this.secondsInput = document.getElementById('customSeconds');
        this.overlay = document.createElement('div');
        this.overlay.className = 'modal-overlay';
        document.body.appendChild(this.overlay);
        
        this.initializeControls();
    }

    initializeControls() {
        // Открытие модального окна
        document.getElementById('customTimerBtn').addEventListener('click', () => {
            this.showModal();
        });

        // Установка времени
        document.getElementById('setCustomTime').addEventListener('click', () => {
            this.setCustomTime();
        });

        // Отмена
        document.getElementById('cancelCustomTime').addEventListener('click', () => {
            this.hideModal();
        });

        // Закрытие по клику вне модального окна
        this.overlay.addEventListener('click', () => {
            this.hideModal();
        });

        // Ограничение ввода
        this.minutesInput.addEventListener('input', () => {
            this.validateInput(this.minutesInput, 180);
        });

        this.secondsInput.addEventListener('input', () => {
            this.validateInput(this.secondsInput, 59);
        });

        // Обработка клавиши Enter
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && this.modal.classList.contains('active')) {
                this.setCustomTime();
            }
            if (e.key === 'Escape' && this.modal.classList.contains('active')) {
                this.hideModal();
            }
        });
    }

    showModal() {
        this.modal.classList.add('active');
        this.overlay.classList.add('active');
        this.minutesInput.focus();
    }

    hideModal() {
        this.modal.classList.remove('active');
        this.overlay.classList.remove('active');
    }

    validateInput(input, max) {
        let value = parseInt(input.value);
        if (isNaN(value) || value < 0) {
            input.value = 0;
        } else if (value > max) {
            input.value = max;
        }
    }

    setCustomTime() {
        const minutes = parseInt(this.minutesInput.value) || 0;
        const seconds = parseInt(this.secondsInput.value) || 0;
        const totalSeconds = (minutes * 60) + seconds;

        if (totalSeconds > 0) {
            this.mainTimer.setCustomTime(totalSeconds);
            this.hideModal();
            
            // Сброс активных кнопок режимов
            document.querySelectorAll('.mode-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            document.getElementById('customTimerBtn').classList.add('active');
        } else {
            alert('Пожалуйста, установите время больше 0');
        }
    }
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    // Инициализация темы
    const themeManager = new ThemeManager();
    
    const timer = new Timer();
    Progress.init();
    const waterTracker = new WaterTracker();
    const customTimer = new CustomTimer(timer);

    // Добавляем горячие клавиши
    document.addEventListener('keydown', (e) => {
        if (e.code === 'Space') {
            e.preventDefault();
            if (timer.isRunning) {
                timer.pause();
            } else {
                timer.start();
            }
        }
        if (e.code === 'KeyR' && e.ctrlKey) {
            e.preventDefault();
            timer.reset();
        }
    });
}); 