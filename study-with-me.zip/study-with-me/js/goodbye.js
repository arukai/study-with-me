document.addEventListener('DOMContentLoaded', () => {
    // Получаем данные сессии из localStorage
    const sessionData = {
        minutes: localStorage.getItem('sessionMinutes') || 0,
        pomodoros: localStorage.getItem('sessionPomodoros') || 0,
        water: localStorage.getItem('sessionWater') || 0
    };

    // Обновляем статистику на странице
    document.getElementById('sessionMinutes').textContent = sessionData.minutes;
    document.getElementById('completedPomodoros').textContent = sessionData.pomodoros;
    document.getElementById('waterDrank').textContent = sessionData.water;

    // Генерируем мотивационное сообщение
    generateMotivationMessage(sessionData);
});

function generateMotivationMessage(data) {
    const messages = [
        'Ваша продуктивность подросла! 🌱',
        'Отличная работа! Продолжайте в том же духе! 🌟',
        'Вы становитесь лучше с каждой сессией! 💪',
        'Маленькие шаги ведут к большим достижениям! 🎯'
    ];
    
    const messageElement = document.getElementById('motivationText');
    messageElement.textContent = messages[Math.floor(Math.random() * messages.length)];
}

function shareResults() {
    const minutes = document.getElementById('sessionMinutes').textContent;
    const text = `Я занимался ${minutes} минут с Study with me! 📚✨`;
    
    if (navigator.share) {
        navigator.share({
            title: 'Мои результаты в Study with me',
            text: text,
            url: window.location.origin
        });
    } else {
        // Fallback для браузеров без поддержки Web Share API
        alert('Скопируйте текст: ' + text);
    }
} 